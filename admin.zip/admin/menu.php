<div id='cssmenu'>
<ul style="color:white" >
   <li><a style="color:white" href='#'><i class="fa fa-gear fa-fw"></i>&nbsp; Pengaturan </a>
       <ul>
         <li><a style="color:white"  href='?manage'><span>Akun Admin</span></a></li>
         <li><a style="color:white"  href='#'><span>Edit Data</span></a></li>
         <li><a style="color:white"  href='#'><span>Ganti Password</span></a></li>
         
      </ul>

   </li>
   <li class='active has-sub'><a style="color:white"  href=''><i class="fa fa-envelope fa-fw"></i>&nbsp; Surat Masuk</a>
      <ul>
         <li><a style="color:white"  href='?addsurat'><span>Catat Surat</span></a></li>
         <li><a style="color:white"  href='#'><span>Cari Surat</span></a></li>
         <li><a style="color:white"  href='#'><span>Status Surat</span></a></li>
         
      </ul>
   </li>

   <li class='active has-sub'><a style="color:white" href='#'><i class="fa fa-envelope-o fa-fw"></i>&nbsp; Surat Keluar</a>
      <ul>
         <li><a style="color:white" href='?addsuratkeluar'><span>Tulis Surat</span></a></li>
         <li><a style="color:white" href='#'><span>Lihat Surat</span></a></li>
      </ul>
   </li>
   <li class='last'><a style="color:white" href='logout.php'><i class="fa fa-sign-out fa-fw"></i>&nbsp; Logout</a></li>
</ul>
</div>
