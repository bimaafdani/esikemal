<?php
include("koneksi.php");
include('index.php');
?>