<?php
// koneksi ke database
$link = mysqli_connect('localhost', 'root', '', 'select2');
?>